Kulkarni CRM - Jetpack Compose project (demo)
---------------------------------------------
This project is a ready-to-import Android Studio project with:
- Jetpack Compose UI (single-activity)
- Room local database (Lead entity)
- Firebase integration placeholders (add google-services.json)
- WorkManager-based reminders: set "Reminder minutes from now" when saving a lead to get a demo notification.

How to build:
1. Download and extract this folder.
2. Open Android Studio -> Open an existing project -> select this folder.
3. Let Gradle sync. Add google-services.json if you want Firebase features.
4. Build -> Build APK(s) to generate an installable APK.

Notes:
- Reminder scheduling uses WorkManager and triggers a notification after the specified minutes.
- For production, secure your Firestore rules and don't use long test modes.
