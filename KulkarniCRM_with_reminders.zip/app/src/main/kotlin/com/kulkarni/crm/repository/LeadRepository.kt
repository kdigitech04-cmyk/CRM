package com.kulkarni.crm.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.kulkarni.crm.data.LeadDao
import com.kulkarni.crm.models.Lead
import kotlinx.coroutines.tasks.await

class LeadRepository(private val leadDao: LeadDao) {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()

    fun allLeads(): LiveData<List<Lead>> = leadDao.getAll()

    suspend fun getLead(id: String): Lead? = leadDao.getById(id)

    suspend fun addLead(lead: Lead) {
        leadDao.insert(lead)
        try {
            val uid = auth.currentUser?.uid ?: "anonymous"
            firestore.collection("users").document(uid)
                .collection("leads").document(lead.id)
                .set(lead.toMap()).await()
        } catch (e: Exception) { Log.e("LeadRepo","Firestore add failed: ${e.message}") }
    }

    suspend fun updateLead(lead: Lead) {
        leadDao.update(lead)
        try {
            val uid = auth.currentUser?.uid ?: "anonymous"
            firestore.collection("users").document(uid)
                .collection("leads").document(lead.id)
                .set(lead.toMap()).await()
        } catch (e: Exception) { Log.e("LeadRepo","Firestore update failed: ${e.message}") }
    }

    suspend fun deleteLead(lead: Lead) {
        leadDao.delete(lead)
        try {
            val uid = auth.currentUser?.uid ?: "anonymous"
            firestore.collection("users").document(uid)
                .collection("leads").document(lead.id).delete().await()
        } catch (e: Exception) { Log.e("LeadRepo","Firestore delete failed: ${e.message}") }
    }

    suspend fun syncFromFirestore() {
        try {
            val uid = auth.currentUser?.uid ?: return
            val snaps = firestore.collection("users").document(uid)
                .collection("leads").get().await()
            snaps.documents.forEach { doc ->
                val lead = Lead.fromSnapshot(doc)
                leadDao.insert(lead)
            }
        } catch (e: Exception) { Log.e("LeadRepo","Sync failed: ${e.message}") }
    }
}
