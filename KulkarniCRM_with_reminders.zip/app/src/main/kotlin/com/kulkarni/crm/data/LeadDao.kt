package com.kulkarni.crm.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.kulkarni.crm.models.Lead

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads ORDER BY createdAt DESC")
    fun getAll(): LiveData<List<Lead>>

    @Query("SELECT * FROM leads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Lead?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(lead: Lead)

    @Update
    suspend fun update(lead: Lead)

    @Delete
    suspend fun delete(lead: Lead)
}
