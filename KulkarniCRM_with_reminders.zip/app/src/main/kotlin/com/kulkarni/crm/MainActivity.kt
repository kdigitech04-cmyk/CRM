package com.kulkarni.crm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.kulkarni.crm.ui.NavGraph
import com.kulkarni.crm.ui.theme.KulkarniCRMTheme
import com.kulkarni.crm.viewmodel.LeadViewModel
import com.kulkarni.crm.viewmodel.LeadViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KulkarniCRMTheme {
                val navController = rememberNavController()
                val vm: LeadViewModel = viewModel(factory = LeadViewModelFactory(application))
                // initial sync
                vm.syncFromRemote()
                NavGraph(navController = navController, viewModel = vm)
            }
        }
    }
}
