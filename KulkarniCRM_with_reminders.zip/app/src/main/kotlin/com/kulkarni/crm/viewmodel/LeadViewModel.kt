package com.kulkarni.crm.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.kulkarni.crm.data.AppDatabase
import com.kulkarni.crm.models.Lead
import com.kulkarni.crm.repository.LeadRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LeadViewModel(application: Application) : AndroidViewModel(application) {
    private val repo: LeadRepository
    val allLeads: LiveData<List<Lead>>

    init {
        val db = AppDatabase.getInstance(application)
        repo = LeadRepository(db.leadDao())
        allLeads = repo.allLeads()
    }

    fun getLead(id: String): LiveData<Lead?> {
        val out = MutableLiveData<Lead?>()
        viewModelScope.launch(Dispatchers.IO) {
            out.postValue(repo.getLead(id))
        }
        return out
    }

    fun saveLead(lead: Lead) = viewModelScope.launch(Dispatchers.IO) { repo.addLead(lead) }
    fun updateLead(lead: Lead) = viewModelScope.launch(Dispatchers.IO) { repo.updateLead(lead) }
    fun deleteLead(lead: Lead) = viewModelScope.launch(Dispatchers.IO) { repo.deleteLead(lead) }
    fun syncFromRemote() = viewModelScope.launch(Dispatchers.IO) { repo.syncFromFirestore() }
}
