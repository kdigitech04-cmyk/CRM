package com.kulkarni.crm.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.google.firebase.auth.FirebaseAuth
import com.kulkarni.crm.models.Lead
import com.kulkarni.crm.viewmodel.LeadViewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextOverflow
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit
import com.kulkarni.crm.reminder.ReminderWorker

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Leads : Screen("leads")
    object AddEdit : Screen("addedit?leadId={leadId}") {
        fun route(leadId: String? = null) = if (leadId == null) "addedit" else "addedit?leadId=$leadId"
    }
    object Detail : Screen("detail/{leadId}") {
        fun route(leadId: String) = "detail/$leadId"
    }
}

@Composable
fun NavGraph(navController: NavHostController, viewModel: LeadViewModel) {
    NavHost(navController, startDestination = Screen.Login.route) {
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.Leads.route) { LeadListScreen(navController, viewModel) }
        composable("addedit") { AddEditLeadScreen(navController, viewModel, null) }
        composable("addedit?leadId={leadId}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("leadId")
            AddEditLeadScreen(navController, viewModel, id)
        }
        composable("detail/{leadId}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("leadId") ?: ""
            LeadDetailScreen(navController, viewModel, id)
        }
    }
}

@Composable
fun LoginScreen(navController: NavHostController) {
    val auth = FirebaseAuth.getInstance()
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val scaffoldState = rememberScaffoldState()

    LaunchedEffect(auth.currentUser) {
        if (auth.currentUser != null) {
            navController.navigate(Screen.Leads.route) { popUpTo(Screen.Login.route) { inclusive = true } }
        }
    }

    Scaffold(scaffoldState = scaffoldState) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
            Text("Kulkarni CRM", style = MaterialTheme.typography.h5)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                if (email.isBlank() || pass.length < 6) {
                    scaffoldState.snackbarHostState.showSnackbar("Enter valid credentials")
                    return@Button
                }
                auth.signInWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        navController.navigate(Screen.Leads.route) { popUpTo(Screen.Login.route) { inclusive = true } }
                    } else {
                        scaffoldState.snackbarHostState.showSnackbar("Login failed: ${task.exception?.message}")
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = {
                if (email.isBlank() || pass.length < 6) {
                    scaffoldState.snackbarHostState.showSnackbar("Enter valid credentials")
                    return@TextButton
                }
                auth.createUserWithEmailAndPassword(email.trim(), pass).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        navController.navigate(Screen.Leads.route) { popUpTo(Screen.Login.route) { inclusive = true } }
                    } else {
                        scaffoldState.snackbarHostState.showSnackbar("Register failed: ${task.exception?.message}")
                    }
                }
            }) { Text("Register") }
        }
    }
}

@Composable
fun LeadListScreen(navController: NavHostController, viewModel: LeadViewModel) {
    val leads by viewModel.allLeads.observeAsState(emptyList())
    var query by remember { mutableStateOf("") }

    val filtered = if (query.isBlank()) leads else leads.filter {
        it.name.contains(query, true) || it.phone.contains(query, true) || (it.modelInterested?.contains(query, true) ?: false)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Leads") }, actions = {
            IconButton(onClick = {
                FirebaseAuth.getInstance().signOut()
                navController.navigate(Screen.Login.route) { popUpTo(Screen.Leads.route) { inclusive = true } }
            }) { Text("Logout") }
        }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("addedit") }) { Icon(Icons.Default.Add, contentDescription = "Add") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search (name, phone, model)") }, modifier = Modifier.fillMaxWidth().padding(8.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No leads yet. Tap + to add.")
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(filtered) { lead ->
                        LeadRow(lead) { navController.navigate(Screen.Detail.route(lead.id)) }
                    }
                }
            }
        }
    }
}

@Composable
fun LeadRow(lead: Lead, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(8.dp).clickable { onClick() }) {
        Column(Modifier.padding(12.dp)) {
            Text(lead.name, style = MaterialTheme.typography.subtitle1, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(lead.phone, style = MaterialTheme.typography.body2)
            if (!lead.modelInterested.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("Model: ${lead.modelInterested}", style = MaterialTheme.typography.body2)
            }
            lead.reminderMinutesFromNow?.let {
                Spacer(Modifier.height(4.dp))
                Text("Reminder in ${it} min", style = MaterialTheme.typography.caption)
            }
        }
    }
}

@Composable
fun AddEditLeadScreen(navController: NavHostController, viewModel: LeadViewModel, leadId: String?) {
    val editingLead by (leadId?.let { viewModel.getLead(it) } ?: mutableStateOf(null)).observeAsState()
    var name by remember { mutableStateOf(editingLead?.name ?: "") }
    var phone by remember { mutableStateOf(editingLead?.phone ?: "") }
    var email by remember { mutableStateOf(editingLead?.email ?: "") }
    var city by remember { mutableStateOf(editingLead?.city ?: "") }
    var model by remember { mutableStateOf(editingLead?.modelInterested ?: "") }
    var notes by remember { mutableStateOf(editingLead?.notes ?: "") }
    var reminderMinutes by remember { mutableStateOf(editingLead?.reminderMinutesFromNow?.toString() ?: "") }

    LaunchedEffect(editingLead) {
        editingLead?.let {
            name = it.name
            phone = it.phone
            email = it.email ?: ""
            city = it.city ?: ""
            model = it.modelInterested ?: ""
            notes = it.notes ?: ""
            reminderMinutes = it.reminderMinutesFromNow?.toString() ?: ""
        }
    }

    val scaffoldState = rememberScaffoldState()

    Scaffold(topBar = { TopAppBar(title = { Text(if (leadId == null) "Add Lead" else "Edit Lead") }) },
        scaffoldState = scaffoldState) { padding ->
        Column(Modifier.fillMaxSize().padding(16.dp).padding(padding)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model Interested") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), maxLines = 4)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = reminderMinutes, onValueChange = { reminderMinutes = it.filter { ch-> ch.isDigit() } }, label = { Text("Reminder minutes from now (optional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                if (name.isBlank() || phone.isBlank()) {
                    // show snackbar
                    return@Button
                }
                val rm = reminderMinutes.toIntOrNull()
                val lead = editingLead?.copy(
                    name = name, phone = phone, email = email.ifBlank { null },
                    city = city.ifBlank { null }, modelInterested = model.ifBlank { null },
                    notes = notes.ifBlank { null }, reminderMinutesFromNow = rm
                ) ?: Lead(name = name, phone = phone, email = email.ifBlank { null }, city = city.ifBlank { null }, modelInterested = model.ifBlank { null }, notes = notes.ifBlank { null }, reminderMinutesFromNow = rm)
                if (leadId == null) viewModel.saveLead(lead) else viewModel.updateLead(lead)

                // schedule reminder using WorkManager if set
                rm?.let { minutes ->
                    val data = workDataOf("title" to "Reminder: ${lead.name}", "text" to "Follow up with ${lead.name} (${lead.phone})")
                    val req = OneTimeWorkRequestBuilder<ReminderWorker>()
                        .setInitialDelay(minutes.toLong(), TimeUnit.MINUTES)
                        .setInputData(data)
                        .build()
                    WorkManager.getInstance(LocalContext.current).enqueue(req)
                }

                navController.popBackStack()
            }, modifier = Modifier.fillMaxWidth()) {
                Text("Save")
            }
        }
    }
}

@Composable
fun LeadDetailScreen(navController: NavHostController, viewModel: LeadViewModel, leadId: String) {
    val lead by viewModel.getLead(leadId).observeAsState()
    val scaffoldState = rememberScaffoldState()

    BackHandler { navController.popBackStack() }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Lead Details") }, actions = {
            IconButton(onClick = { lead?.let { viewModel.deleteLead(it); navController.popBackStack() } }) {
                Text("Delete")
            }
            IconButton(onClick = { navController.navigate(Screen.AddEdit.route(lead?.id)) }) { Text("Edit") }
        })
    }, scaffoldState = scaffoldState) { padding ->
        if (lead == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            Column(Modifier.fillMaxSize().padding(16.dp).padding(padding)) {
                Text(lead!!.name, style = MaterialTheme.typography.h6)
                Spacer(Modifier.height(8.dp))
                Text("Phone: ${lead!!.phone}")
                lead!!.email?.let { Text("Email: $it") }
                lead!!.city?.let { Text("City: $it") }
                lead!!.modelInterested?.let { Text("Model: $it") }
                Spacer(Modifier.height(8.dp))
                lead!!.notes?.let { Text("Notes: $it") }
                lead!!.reminderMinutesFromNow?.let { Text("Reminder set (${it} min from save)") }
            }
        }
    }
}
