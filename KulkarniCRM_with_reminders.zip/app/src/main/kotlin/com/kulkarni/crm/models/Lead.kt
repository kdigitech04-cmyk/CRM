package com.kulkarni.crm.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import java.util.UUID

@Entity(tableName = "leads")
data class Lead(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var phone: String = "",
    var email: String? = null,
    var city: String? = null,
    var modelInterested: String? = null,
    var notes: String? = null,
    var reminderMinutesFromNow: Int? = null, // schedule a reminder X minutes from save - demo
    var createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "name" to name,
        "phone" to phone,
        "email" to email,
        "city" to city,
        "modelInterested" to modelInterested,
        "notes" to notes,
        "reminderMinutesFromNow" to reminderMinutesFromNow,
        "createdAt" to Timestamp.now()
    )
    companion object {
        fun fromSnapshot(snap: DocumentSnapshot): Lead {
            val data = snap.data ?: mapOf<String, Any?>()
            return Lead(
                id = data["id"] as? String ?: snap.id,
                name = data["name"] as? String ?: "",
                phone = data["phone"] as? String ?: "",
                email = data["email"] as? String,
                city = data["city"] as? String,
                modelInterested = data["modelInterested"] as? String,
                notes = data["notes"] as? String,
                reminderMinutesFromNow = (data["reminderMinutesFromNow"] as? Long)?.toInt(),
                createdAt = (data["createdAt"] as? Timestamp)?.toDate()?.time ?: System.currentTimeMillis()
            )
        }
    }
}
